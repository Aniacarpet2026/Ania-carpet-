
package com.aniacarpet.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF06263A)
private val Gold = Color(0xFFD7A84A)
private val Bg = Color(0xFFF6F3ED)

data class Carpet(val code:String,val name:String,val price:String,val size:String,val stock:Int)

val carpets = listOf(
    Carpet("1001","لارا نقره ای","25,000,000","12 متری",25),
    Carpet("1002","نیلا نقره ای","25,000,000","12 متری",18),
    Carpet("1003","یسنا صدفی","25,000,000","12 متری",12),
    Carpet("1004","تیام صدفی","25,000,000","12 متری",9)
)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AniaApp() }
    }
}

@Composable
fun AniaApp() {
    var page by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf(carpets.first()) }
    var cartCount by remember { mutableStateOf(0) }

    MaterialTheme(colorScheme = lightColorScheme(primary=Navy, secondary=Gold, background=Bg)) {
        Scaffold(
            containerColor = Bg,
            topBar = { TopBar(onNotify={page="notifications"}) },
            bottomBar = { if(page=="home") BottomBar(page){page=it} }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(page) {
                    "home" -> Home(
                        onPage={page=it},
                        onProduct={selected=it;page="product"}
                    )
                    "catalog" -> Catalog(onProduct={selected=it;page="product"}, onAdd={cartCount++})
                    "product" -> Product(selected, onBack={page="catalog"}, onAdd={cartCount++})
                    "customers" -> Customers(onAdd={page="addCustomer"})
                    "addCustomer" -> Form("افزودن مشتری","ذخیره مشتری")
                    "order" -> Order(cartCount)
                    "tracking" -> Tracking()
                    "reports" -> Reports()
                    "notifications" -> Notifications()
                    "settings" -> Settings()
                }
            }
        }
    }
}

@Composable fun TopBar(onNotify:()->Unit) {
    Row(Modifier.fillMaxWidth().background(Navy).padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
        Text("✦ Ania", color=Gold, fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text(" carpet", color=Color.White, fontSize=13.sp)
        Spacer(Modifier.weight(1f))
        IconButton(onClick=onNotify){Icon(Icons.Default.NotificationsNone,null,tint=Color.White)}
        Text("سلام علی",color=Color.White,fontWeight=FontWeight.Bold)
    }
}

@Composable fun Home(onPage:(String)->Unit,onProduct:(Carpet)->Unit) {
    Column(Modifier.fillMaxSize().padding(15.dp)) {
        Text("صفحه اصلی",fontSize=24.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value="",onValueChange={},placeholder={Text("جستجوی فرش، کد یا نام مشتری...")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Spacer(Modifier.height(12.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Navy),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("فرش آنیا",color=Gold,fontSize=25.sp,fontWeight=FontWeight.Bold)
                Text("انتخابی مطمئن برای مشتریان شما",color=Color.White,fontSize=15.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick={onPage("catalog")},colors=ButtonDefaults.buttonColors(containerColor=Gold)){Text("مشاهده کاتالوگ",color=Navy)}
            }
        }
        Spacer(Modifier.height(12.dp))
        val actions=listOf(
            "کاتالوگ فرش" to "catalog","مشتریان" to "customers","سفارش جدید" to "order",
            "پیگیری فروش" to "tracking","گزارش‌ها" to "reports","تنظیمات" to "settings"
        )
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                actions.take(3).forEach{Action(it.first){onPage(it.second)}}
            }
            Column(Modifier.weight(1f)) {
                actions.drop(3).forEach{Action(it.first){onPage(it.second)}}
            }
        }
        Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(15.dp)) {
                Text("فروش امروز",fontSize=18.sp,fontWeight=FontWeight.Bold)
                Row(Modifier.fillMaxWidth().padding(top=12.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                    Metric("۱۲","سفارش"); Metric("۲۴۸M","تومان فروش"); Metric("۳","مشتری جدید")
                }
            }
        }
        Text("محصولات منتخب",fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=10.dp))
        LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            items(carpets){p-> ProductCard(p){onProduct(p)}}
        }
    }
}
@Composable fun Action(title:String,on:()->Unit){Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable{on()},colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Star,null,tint=Gold);Text(title,fontWeight=FontWeight.Bold)}}}
@Composable fun Metric(n:String,t:String){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(n,fontWeight=FontWeight.Bold,fontSize=18.sp);Text(t,fontSize=11.sp,color=Color.Gray)}}
@Composable fun ProductCard(p:Carpet,on:()->Unit){Card(Modifier.width(180.dp).clickable{on()},colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(8.dp)){Box(Modifier.fillMaxWidth().height(110.dp).background(Color.LightGray));Text(p.name,fontWeight=FontWeight.Bold);Text(p.size,fontSize=12.sp,color=Color.Gray);Text("${p.price} تومان",fontWeight=FontWeight.Bold)}}}

@Composable fun Catalog(onProduct:(Carpet)->Unit,onAdd:()->Unit){
    Column(Modifier.fillMaxSize().padding(15.dp)){Text("کاتالوگ فرش",fontSize=24.sp,fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.padding(vertical=10.dp)){listOf("همه","جدید","پرفروش","تخفیف ویژه").forEach{AssistChip(onClick={},label={Text(it)})}}
        LazyVerticalGrid(columns=GridCells.Fixed(2),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(carpets){p->Card(colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(8.dp)){Box(Modifier.fillMaxWidth().height(130.dp).background(Color(0xFFE6E1D8)));Text(p.name,fontWeight=FontWeight.Bold);Text("کد ${p.code} • ${p.size}",fontSize=11.sp);Text("${p.price} تومان",fontWeight=FontWeight.Bold);Button(onClick={onAdd()},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Navy)){Text("افزودن")};TextButton(onClick={onProduct(p)}){Text("مشاهده جزئیات")}}}}}
    }
}
@Composable fun Product(p:Carpet,onBack:()->Unit,onAdd:()->Unit){Column(Modifier.fillMaxSize().padding(15.dp)){Text("‹ بازگشت",modifier=Modifier.clickable{onBack()},fontSize=16.sp);Spacer(Modifier.height(8.dp));Box(Modifier.fillMaxWidth().height(260.dp).background(Color(0xFFE4DED4),RoundedCornerShape(15.dp)));Text(p.name,fontSize=24.sp,fontWeight=FontWeight.Bold);Text("کد: ${p.code}",color=Color.Gray);Row(Modifier.fillMaxWidth().padding(vertical=15.dp),horizontalArrangement=Arrangement.SpaceAround){Info("ابعاد",p.size);Info("شانه","700");Info("تراکم","2550")};Card(colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){Text("${p.price} تومان",fontSize=25.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(16.dp))};Text("موجودی: ${p.stock} تخته",modifier=Modifier.padding(vertical=10.dp));Button(onClick=onAdd,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Navy)){Text("ثبت سفارش")}}
}
@Composable fun Info(a:String,b:String){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(a,color=Color.Gray);Text(b,fontWeight=FontWeight.Bold)}}

@Composable fun Customers(onAdd:()->Unit){Column(Modifier.fillMaxSize().padding(15.dp)){Text("مشتریان",fontSize=24.sp,fontWeight=FontWeight.Bold);OutlinedTextField(value="",onValueChange={},placeholder={Text("جستجوی مشتری...")},modifier=Modifier.fillMaxWidth());customersUI(onAdd)}}
@Composable fun customersUI(onAdd:()->Unit){Column{listOf("آقای محمدی|عمده‌فروش|مشهد|0915 123 4567|A","فروشگاه فرش نگین|فروشنده|تهران|0912 345 6789|B","آقای حسینی|پخش‌کننده|شیراز|0937 765 4321|A","فرش سرای امین|فروشگاه|اصفهان|0913 222 3344|C").forEach{val x=it.split("|");Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Text(x[4],color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.background(if(x[4]=="A")Color(0xFF2FA66A) else if(x[4]=="B")Color(0xFFE0B73F) else Color.Gray).padding(8.dp));Column(Modifier.padding(start=10.dp)){Text(x[0],fontWeight=FontWeight.Bold);Text("${x[1]} • ${x[2]}");Text(x[3],fontSize=12.sp,color=Color.Gray)}}}};Button(onClick=onAdd,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Gold)){Text("+ افزودن مشتری",color=Navy,fontWeight=FontWeight.Bold)}}}
@Composable fun Form(title:String,button:String){Column(Modifier.fillMaxSize().padding(15.dp)){Text(title,fontSize=24.sp,fontWeight=FontWeight.Bold);listOf("نام مشتری","شماره تماس","شهر","آدرس","نوع مشتری","توضیحات").forEach{OutlinedTextField(value="",onValueChange={},label={Text(it)},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp))};Button(onClick={},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Navy)){Text(button)}}}
@Composable fun Order(cart:Int){Column(Modifier.fillMaxSize().padding(15.dp)){Text("ثبت سفارش جدید",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("تعداد اقلام: $cart",modifier=Modifier.padding(vertical=15.dp));listOf("نام مشتری","شماره تماس","آدرس","توضیحات سفارش").forEach{OutlinedTextField(value="",onValueChange={},label={Text(it)},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp))};Button(onClick={},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Navy)){Text("ثبت سفارش")}}}
@Composable fun Tracking(){SimpleList("پیگیری فروش",listOf("آقای محمدی • مشهد","فروشگاه نگین • تهران","آقای حسینی • تبریز","فرش سرای امین • اصفهان"))}
@Composable fun Reports(){SimpleList("گزارش‌ها و آمار فروش",listOf("فروش امروز: 248,000,000 تومان","فروش ماهانه: 1,420,000,000 تومان","پرفروش‌ترین: لارا نقره ای","پرفروش‌ترین: نیلا نقره ای"))}
@Composable fun Notifications(){SimpleList("اعلان‌ها و یادآوری‌ها",listOf("سفارش جدید ثبت شد","مشتری جدید اضافه شد","پیگیری سفارش موعد دارد","تسویه حساب دریافت شد"))}
@Composable fun Settings(){SimpleList("تنظیمات",listOf("اطلاعات فروشگاه","مدیریت کاربران","اعلان‌ها","پشتیبان‌گیری","درباره Ania Carpet"))}
@Composable fun SimpleList(title:String,items:List<String>){Column(Modifier.fillMaxSize().padding(15.dp)){Text(title,fontSize=24.sp,fontWeight=FontWeight.Bold);items.forEach{Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Text(it,modifier=Modifier.padding(18.dp),fontWeight=FontWeight.Bold)}}}}
@Composable fun BottomBar(page:String,on:(String)->Unit){NavigationBar(containerColor=Color.White){listOf("home" to "خانه","catalog" to "کاتالوگ","customers" to "مشتریان","order" to "سفارش‌ها").forEach{(id,t)->NavigationBarItem(selected=page==id,onClick={on(id)},icon={Icon(Icons.Default.Home,null)},label={Text(t)})}}}
